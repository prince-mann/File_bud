import Home from "./Home";
import LandingPage from "./LandingPage";
import ErrorPage from "./ErrorPage";
import Login from "./Login";
import Register from "./Register";
import FolderPage from "./FolderPage";

export { Login, Register, Home, LandingPage, ErrorPage, FolderPage };
